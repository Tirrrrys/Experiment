# Luminous — Frontend + Backend

## Struktur
- `frontend/luminous.html` — aplikasi utama
- `frontend/logo.png` — logo
- `frontend/curated.html` — halaman referensi desain (opsional)
- `backend/server.js` — proxy backend Node.js tanpa dependency
- `backend/package.json` — metadata dan `npm start`
- `start.sh` — menjalankan backend dari root paket

## Jalankan
Prasyarat: Node.js 18+.

```sh
sh start.sh
```

Atau:

```sh
cd backend
node server.js
```

Buka `http://localhost:7766`.

Ganti port:

```sh
PORT=8080 node backend/server.js
```

## Deploy
Backend dan frontend bisa dijalankan sebagai satu service Node.js. Start command:
`node backend/server.js` (dari root paket) atau `npm start` (dari folder backend).

## Keamanan
API key tidak disimpan di file mana pun; key hanya ada di localStorage browser dan diteruskan ke backend saat request. Tidak ada dependency npm yang perlu di-install.
